package com.xingcai.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.system.model.po.Dictionary;

/**
 * 数据字典 Mapper 接口
 */
public interface DictionaryMapper extends BaseMapper<Dictionary> {

}
