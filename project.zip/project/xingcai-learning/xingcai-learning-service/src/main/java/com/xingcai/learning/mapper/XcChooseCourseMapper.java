package com.xingcai.learning.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.learning.model.po.XcChooseCourse;


public interface XcChooseCourseMapper extends BaseMapper<XcChooseCourse> {

}
