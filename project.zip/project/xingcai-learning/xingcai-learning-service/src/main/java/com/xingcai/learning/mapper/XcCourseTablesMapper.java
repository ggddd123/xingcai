package com.xingcai.learning.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.learning.model.po.XcCourseTables;


public interface XcCourseTablesMapper extends BaseMapper<XcCourseTables> {

}
