package com.xingcai.messagesdk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xingcai.messagesdk.model.po.MqMessageHistory;

public interface MqMessageHistoryService extends IService<MqMessageHistory> {

}
