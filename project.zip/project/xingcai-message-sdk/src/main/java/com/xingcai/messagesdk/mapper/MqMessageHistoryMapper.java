package com.xingcai.messagesdk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.messagesdk.model.po.MqMessageHistory;


public interface MqMessageHistoryMapper extends BaseMapper<MqMessageHistory> {

}
