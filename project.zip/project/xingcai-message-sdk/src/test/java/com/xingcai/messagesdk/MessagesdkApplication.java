package com.xingcai.messagesdk;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagesdkApplication {
	public static void main(String[] args) {
		SpringApplication.run(MessagesdkApplication.class, args);
	}
}