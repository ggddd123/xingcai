package com.xingcai.orders.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.orders.model.po.XcPayRecord;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 */
public interface XcPayRecordMapper extends BaseMapper<XcPayRecord> {

}
