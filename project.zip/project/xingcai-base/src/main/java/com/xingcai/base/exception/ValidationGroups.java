package com.xingcai.base.exception;

public class ValidationGroups {

    public interface Inster{};
    public interface Update{};
    public interface Delete{};

}
