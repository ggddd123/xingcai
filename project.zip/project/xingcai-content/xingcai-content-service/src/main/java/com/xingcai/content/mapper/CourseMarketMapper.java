package com.xingcai.content.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.content.model.po.CourseMarket;


public interface CourseMarketMapper extends BaseMapper<CourseMarket> {

}
