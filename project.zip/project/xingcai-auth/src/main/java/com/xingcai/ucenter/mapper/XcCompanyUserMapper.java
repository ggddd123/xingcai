package com.xingcai.ucenter.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.ucenter.model.po.XcCompanyUser;


public interface XcCompanyUserMapper extends BaseMapper<XcCompanyUser> {

}
