package com.xingcai.ucenter.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.ucenter.model.po.XcUser;


public interface XcUserMapper extends BaseMapper<XcUser> {

}
