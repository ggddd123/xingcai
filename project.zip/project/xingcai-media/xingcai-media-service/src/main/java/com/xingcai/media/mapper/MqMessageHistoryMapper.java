package com.xingcai.media.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.media.model.po.MqMessageHistory;


public interface MqMessageHistoryMapper extends BaseMapper<MqMessageHistory> {

}
