package com.xingcai.media.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.media.model.po.MediaFiles;


public interface MediaFilesMapper extends BaseMapper<MediaFiles> {

}
