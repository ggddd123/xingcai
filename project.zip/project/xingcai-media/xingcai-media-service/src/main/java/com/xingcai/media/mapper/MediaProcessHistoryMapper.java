package com.xingcai.media.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.media.model.po.MediaProcessHistory;


public interface MediaProcessHistoryMapper extends BaseMapper<MediaProcessHistory> {

}
