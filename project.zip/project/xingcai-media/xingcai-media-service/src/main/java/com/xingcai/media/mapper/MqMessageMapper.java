package com.xingcai.media.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingcai.media.model.po.MqMessage;


public interface MqMessageMapper extends BaseMapper<MqMessage> {

}
